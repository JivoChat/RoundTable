//  ___FILEHEADER___

import Foundation

enum ___VARIABLE_productName:identifier___PresenterUpdate {
    /*
      *PresenterUpdate are the values for updating UI
      the Presenter sends to View via Pipeline
    */
}

final class ___VARIABLE_productName:identifier___Presenter
: RTEModulePresenter<
    ___VARIABLE_productName:identifier___Pipeline,
    ___VARIABLE_productName:identifier___PresenterUpdate,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___CoreEvent,
    ___VARIABLE_productName:identifier___JointInput,
    ___VARIABLE_productName:identifier___State
> {
    override func update(firstAppear: Bool) {
    }
    
    override func handleCore(event: ___VARIABLE_productName:identifier___CoreEvent) {
    }
    
    override func handleView(intent: ___VARIABLE_productName:identifier___ViewIntent) {
    }
    
    override func handleJoint(input: ___VARIABLE_productName:identifier___JointInput) {
    }
}
