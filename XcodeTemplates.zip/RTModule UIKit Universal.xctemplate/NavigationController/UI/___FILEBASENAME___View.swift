//  ___FILEHEADER___

import Foundation
import UIKit

typealias ___VARIABLE_productName:identifier___View = (
    // Feed free to replace it with *ViewController or *NavigationController
    ___VARIABLE_productName:identifier___NavigationController
)

enum ___VARIABLE_productName:identifier___ViewIntent {
}

final class ___VARIABLE_productName:identifier___NavigationController
: RTEModuleViewNavigation<
    ___VARIABLE_productName:identifier___PresenterUpdate,
    ___VARIABLE_productName:identifier___ViewIntent
> {
    init(pipeline: RTEModulePipelineViewNotifier<___VARIABLE_productName:identifier___ViewIntent>) {
        super.init(
            primaryView: ___VARIABLE_productName:identifier___ViewController(pipeline: pipeline)
        )
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

final class ___VARIABLE_productName:identifier___ViewController
: RTEModuleViewCanvas<
    ___VARIABLE_productName:identifier___PresenterUpdate,
    ___VARIABLE_productName:identifier___ViewIntent
> {
    override init(pipeline: RTEModulePipelineViewNotifier<___VARIABLE_productName:identifier___ViewIntent>) {
        super.init(pipeline: pipeline)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func handlePresenter(update: ___VARIABLE_productName:identifier___PresenterUpdate) {
        switch update {
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
//        let layout = getLayout(size: view.bounds.size)
//        tableView.frame = layout.tableViewFrame
    }
    
    private func getLayout(size: CGSize) -> Layout {
        Layout(
            bounds: CGRect(origin: .zero, size: size),
            safeAreaInsets: view.safeAreaInsets
        )
    }
}

fileprivate struct Layout {
    let bounds: CGRect
    let safeAreaInsets: UIEdgeInsets
    
    var tableViewFrame: CGRect {
        return bounds
    }
}
