//  ___FILEHEADER___

import Foundation

typealias ___VARIABLE_productName:identifier___Pipeline = RTEModulePipeline<
    ___VARIABLE_productName:identifier___CoreEvent,
    ___VARIABLE_productName:identifier___PresenterUpdate,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___JointInput,
    ___VARIABLE_productName:identifier___View
>

typealias ___VARIABLE_productName:identifier___ = RTEModule<
    ___VARIABLE_productName:identifier___Pipeline,
    ___VARIABLE_productName:identifier___PresenterUpdate,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___Joint,
    ___VARIABLE_productName:identifier___View
>

func ___VARIABLE_productName:identifier___Assembly(trunk: RTConfigTrunk) -> ___VARIABLE_productName:identifier___ {
    return RTEModuleAssembly(
        pipeline: ___VARIABLE_productName:identifier___Pipeline(),
        state: ___VARIABLE_productName:identifier___State(),
        coreBuilder: { pipeline, state in
            ___VARIABLE_productName:identifier___Core(
                pipeline: pipeline,
                state: state
            )
        },
        presenterBuilder: { pipeline, state in
            ___VARIABLE_productName:identifier___Presenter(
                pipeline: pipeline,
                state: state
            )
        },
        viewBuilder: { pipeline in
            ___VARIABLE_productName:identifier___View(
                pipeline: pipeline
            )
        },
        jointBuilder: { pipeline, state, view in
            ___VARIABLE_productName:identifier___Joint(
                pipeline: pipeline,
                state: state,
                view: view,
                trunk: trunk
            )
        })
}
