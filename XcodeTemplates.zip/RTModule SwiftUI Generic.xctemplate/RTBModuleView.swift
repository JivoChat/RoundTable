//  ___FILEHEADER___

import Foundation
import SwiftUI

class RTBModulePipelineViewNotifier<ViewIntent> {
    func notify(intent: ViewIntent) {}
}
