//  ___FILEHEADER___

import Foundation
import SwiftUI

enum ___VARIABLE_productName:identifier___ViewIntent {
}

struct ___VARIABLE_productName:identifier___View: View {
    let trunk: RTBConfigTrunk?
    
    private let binding: ___VARIABLE_productName:identifier___ViewBinding
    private let pipeline: ___VARIABLE_productName:identifier___Pipeline?
    
    init(trunk: RTBConfigTrunk?, callback: ((___VARIABLE_productName:identifier___JointOutput) -> Void)?) {
        self.trunk = trunk
        
        let binding = ___VARIABLE_productName:identifier___ViewBinding()
        self.binding = binding
        self.pipeline = trunk.flatMap { ___VARIABLE_productName:identifier___Assembly(trunk: $0, binding: binding, callback: callback) }
    }
    
    var body: some View {
        EmptyView()
    }
}
