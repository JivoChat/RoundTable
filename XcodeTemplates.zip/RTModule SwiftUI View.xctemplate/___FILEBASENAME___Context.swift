//  ___FILEHEADER___

import Foundation

final class ___VARIABLE_productName:identifier___State {
}
