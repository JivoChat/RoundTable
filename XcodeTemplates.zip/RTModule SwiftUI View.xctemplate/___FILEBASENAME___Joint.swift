//  ___FILEHEADER___

import Foundation

enum ___VARIABLE_productName:identifier___JointInput {
}

enum ___VARIABLE_productName:identifier___JointOutput {
}

final class ___VARIABLE_productName:identifier___Joint
: RTBModuleJoint<
    ___VARIABLE_productName:identifier___Pipeline,
    ___VARIABLE_productName:identifier___JointOutput,
    ___VARIABLE_productName:identifier___JointInput,
    ___VARIABLE_productName:identifier___CoreEvent,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___State
> {
    override func handleCore(event: ___VARIABLE_productName:identifier___CoreEvent) {
    }
    
    override func handleView(intent: ___VARIABLE_productName:identifier___ViewIntent) {
    }
}
