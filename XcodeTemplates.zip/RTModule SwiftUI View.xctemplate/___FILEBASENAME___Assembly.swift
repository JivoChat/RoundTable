//  ___FILEHEADER___

import Foundation

typealias ___VARIABLE_productName:identifier___Pipeline = RTBModulePipeline<
    ___VARIABLE_productName:identifier___CoreEvent,
    ___VARIABLE_productName:identifier___ViewBinding,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___JointInput
>

func ___VARIABLE_productName:identifier___Assembly(trunk: RTBConfigTrunk, binding: ___VARIABLE_productName:identifier___ViewBinding, callback: ((___VARIABLE_productName:identifier___JointOutput) -> Void)?) -> ___VARIABLE_productName:identifier___Pipeline {
    return RTBModuleAssembly(
        pipeline: ___VARIABLE_productName:identifier___Pipeline(trunk: trunk, binding: binding),
        state: ___VARIABLE_productName:identifier___State(),
        coreBuilder: { pipeline, state in
            ___VARIABLE_productName:identifier___Core(
                pipeline: pipeline,
                state: state
            )
        },
        presenterBuilder: { pipeline, state in
            ___VARIABLE_productName:identifier___Presenter(
                pipeline: pipeline,
                state: state,
                binding: binding
            )
        },
        jointBuilder: { pipeline, state in
            ___VARIABLE_productName:identifier___Joint(
                pipeline: pipeline,
                state: state,
                trunk: trunk,
                callback: callback
            )
        })
}
