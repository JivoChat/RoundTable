//  ___FILEHEADER___

import Foundation

enum ___VARIABLE_productName:identifier___CoreEvent {
}

final class ___VARIABLE_productName:identifier___Core
: RTBModuleCore<
    ___VARIABLE_productName:identifier___Pipeline,
    ___VARIABLE_productName:identifier___CoreEvent,
    ___VARIABLE_productName:identifier___ViewIntent,
    ___VARIABLE_productName:identifier___JointInput,
    ___VARIABLE_productName:identifier___State
> {
    override init(pipeline: ___VARIABLE_productName:identifier___Pipeline, state: ___VARIABLE_productName:identifier___State) {
        super.init(pipeline: pipeline, state: state)
    }

    override func run() {
    }
    
    override func handleView(intent: ___VARIABLE_productName:identifier___ViewIntent) {
    }
    
    override func handleJoint(input: ___VARIABLE_productName:identifier___JointInput) {
    }
}
