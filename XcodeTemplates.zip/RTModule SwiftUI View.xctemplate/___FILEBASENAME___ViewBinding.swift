//  ___FILEHEADER___

import Foundation
import SwiftUI

final class ___VARIABLE_productName:identifier___ViewBinding: ObservableObject {
}
