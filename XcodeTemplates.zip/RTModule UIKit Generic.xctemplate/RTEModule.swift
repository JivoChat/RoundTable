//  ___FILEHEADER___

import Foundation
import UIKit

struct RTEModule<
    PresenterUpdate,
    ViewIntent,
    Joint,
    View: IRTEModulePipelineViewHandler
> where View.PresenterUpdate == PresenterUpdate {
    let view: View
    let joint: Joint
}
